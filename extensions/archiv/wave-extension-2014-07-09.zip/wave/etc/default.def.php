<?php
defined("WAVE_PRIORITY") or define("WAVE_PRIORITY", -10);
// Select style:
//defined("WAVE_STANDARDTHEME") or define( "WAVE_STANDARDTHEME" , "Simple Pop Theme" );
//defined("WAVE_STANDARDTHEME") or define( "WAVE_STANDARDTHEME" , "Simple Theme v2" );
defined("WAVE_STANDARDTHEME") or define( "WAVE_STANDARDTHEME" , "Simple" );


// Directory Definitions:

// Path in your open-sTeam server to the room you want to use for the website:
defined("WAVE_PATH_INTERN") or define( "WAVE_PATH_INTERN", "home/wave/" );

?>