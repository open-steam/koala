<?php
namespace Wave\Model;
class InternalWaveDownload extends WaveDownload {
	
}
?>