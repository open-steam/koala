<?php 
interface ITagExtension {
	public function processContent($html, $page);
}
?>