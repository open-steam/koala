<?php
namespace Wave\Model;
abstract class WaveDownload {
	abstract function download();
}
?>