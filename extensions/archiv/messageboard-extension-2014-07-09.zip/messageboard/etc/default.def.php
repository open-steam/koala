<?php
//defined("MANAGE_GROUPS_MEMBERSHIP") or define("MANAGE_GROUPS_MEMBERSHIP", true);

?>