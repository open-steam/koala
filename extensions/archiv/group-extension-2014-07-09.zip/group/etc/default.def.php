<?php
defined("MANAGE_GROUPS_MEMBERSHIP") or define("MANAGE_GROUPS_MEMBERSHIP", true);
defined("CREATE_GROUPS") or define("CREATE_GROUPS", true);
//defined("CLASS_ROOM") or define("CLASS_ROOM", true);
//defined("CLASS_CONTAINER") or define("CLASS_CONTAINER", true);
defined("STEAM_PUBLIC_GROUP") or define("STEAM_PUBLIC_GROUP", true);
//defined("CLASS_GROUP") or define("CLASS_GROUP", true);
?>