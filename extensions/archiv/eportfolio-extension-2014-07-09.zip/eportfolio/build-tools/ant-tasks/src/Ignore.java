import java.util.Vector;

public class Ignore {

	private String prefix;

	public void setPrefix ( String prefix ) {
		this.prefix = prefix;
	}

	public String getPrefix () {
		return prefix;
	}
}
