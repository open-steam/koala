<?php
namespace Portfolio\Commands;
class NewElement extends \AbstractCommand implements \IFrameCommand, \IAjaxCommand {
	
	private $params;
	private $id;
	
	public function validateData(\IRequestObject $requestObject) {
		return true;
	}
	
	public function processData(\IRequestObject $requestObject) {
		if ($requestObject instanceof \UrlRequestObject) {
			$this->params = $requestObject->getParams();
			isset($this->params[0]) ? $this->id = $this->params[0]: "";
		} else if ($requestObject instanceof \AjaxRequestObject) {
			$this->params = $requestObject->getParams();
			isset($this->params["id"]) ? $this->id = $this->params["id"]: "";
		}
	}
	
	public function ajaxResponse(\AjaxResponseObject $ajaxResponseObject) {
		
		$commands = array();
		$commands[] = new \Explorer\Commands\NewDocumentForm();
		$commands[] = new \Explorer\Commands\NewFolderForm();
		$commands[] = new \Portfolio\Commands\NewArtefactForm();
		
		
		$object = \steam_factory::get_object($GLOBALS["STEAM"]->get_id(), $this->id);
		$dialog = new \Widgets\Dialog();
		$dialog->setTitle("Erstelle ein neues Artefakt");
		
		$dialog->setPositionX($this->params["mouseX"]);
		$dialog->setPositionY($this->params["mouseY"]);
		
		$html = "<div id=\"wizard\" style=\"margin-left: 20px; margin-right: 20px\">";
		
		foreach ($commands as $command) {
			$namespaces = $command->getExtension()->getUrlNamespaces();
			$html .= "<a href=\"\" onclick=\"sendRequest('{$command->getCommandName()}', {'id':{$this->id}}, 'wizard', 'wizard', null, null, '{$namespaces[0]}');return false;\" title=\"{$command->getExtension()->getObjectReadableDescription()}\"><img src=\"{$command->getExtension()->getObjectIconUrl()}\"> {$command->getExtension()->getObjectReadableName()}</a><br>";
		}
		$html .= "</div><div id=\"wizard_wrapper\"></div>";
		
		
		$rawHtml = new \Widgets\RawHtml();
		$rawHtml->setHtml($html);
		
		$dialog->addWidget($rawHtml);
		
		$ajaxResponseObject->setStatus("ok");
		$ajaxResponseObject->addWidget($dialog);
		return $ajaxResponseObject;
	}
	
	public function frameResponse(\FrameResponseObject $frameResponseObject) {
		
		$currentUser = $GLOBALS["STEAM"]->get_current_steam_user();
		$object = $currentUser->get_workroom();
		
		$dialog = new \Widgets\Dialog();
		$dialog->setTitle("Eigenschaften von " . $object->get_name());
		
		$dialog->setContent("Nulla dui purus, eleifend vel, consequat non, <br>
							dictum porta, nulla. Duis ante mi, laoreet ut,  <br>
							commodo eleifend, cursus nec, lorem. Aenean eu est.  <br>
							Etiam imperdiet turpis. Praesent nec augue. Curabitur  <br>
							ligula quam, rutrum id, tempor sed, consequat ac, dui. <br>
							Vestibulum accumsan eros nec magna. Vestibulum vitae dui. <br>
							Vestibulum nec ligula et lorem consequat ullamcorper.  <br>
							Class aptent taciti sociosqu ad litora torquent per  <br>
							conubia nostra, per inceptos hymenaeos. Phasellus  <br>
							eget nisl ut elit porta ullamcorper. Maecenas  <br>
							tincidunt velit quis orci. Sed in dui. Nullam ut  <br>
							mauris eu mi mollis luctus. Class aptent taciti  <br>
							sociosqu ad litora torquent per conubia nostra, per  <br>
							inceptos hymenaeos. Sed cursus cursus velit. Sed a  <br>
							massa. Duis dignissim euismod quam. Nullam euismod  <br>
							metus ut orci. Vestibulum erat libero, scelerisque et,  <br>
							porttitor et, varius a, leo.");
		$dialog->setButtons(array(array("name"=>"speichern", "href"=>"save")));
		return $dialog->getHtml();
	}
}
?>