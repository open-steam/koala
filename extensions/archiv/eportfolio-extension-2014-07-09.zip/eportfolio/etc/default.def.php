<?php
//defined("PORTFOLIO_GOD_MODE") or define("PORTFOLIO_GOD_MODE", true);

// define of attribute names for Portfolio objects
defined("PORTFOLIO_PREFIX") or define("PORTFOLIO_PREFIX", "EP_");
defined("PORTFOLIO_MANAGER_GROUP") or define("PORTFOLIO_MANAGER_GROUP", "PortfolioManager");
defined("PORTFOLIO_VIEWER_GROUP") or define("PORTFOLIO_VIEWER_GROUP", "PortfolioViewer");

?>