<?php
namespace Calendar\Model;
class Calendar extends \AbstractObjectModel {
	
	public static function isObject(\steam_object $steamObject) {
	
	}
	
}
?>