<?php
// CHANGE VALUES OF ARRAY $content


	$content['text'] = $_POST['text'];

?>