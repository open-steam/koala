<?php
defined("ALL_COURSES") or define("ALL_COURSES", true);
defined("YOUR_COURSES") or define("YOUR_COURSES", true);
defined("ADD_COURSE") or define("ADD_COURSE", true);
defined("IMPORT_COURSE_FROM_PAUL") or define("IMPORT_COURSE_FROM_PAUL", true);
defined("MANAGE_SEMESTER") or define("MANAGE_SEMESTER", true);
defined("ADD_SEMESTER") or define("ADD_SEMESTER", true);
defined("SEMESTER_URL") or define("SEMESTER_URL", "semester");
?>