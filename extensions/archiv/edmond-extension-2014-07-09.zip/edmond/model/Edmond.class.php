<?php
namespace Edmond\Model;
class Edmond extends \AbstractObjectModel {
	
	public static function isObject(\steam_object $steamObject) {
	
	}
	
}
?>