<?php
namespace Gallery\Model;
class Gallery extends \AbstractObjectModel {
	
	public static function isObject(\steam_object $steamObject) {
	
	}
	
}
?>