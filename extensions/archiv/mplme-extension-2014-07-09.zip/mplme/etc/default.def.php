<?php 
defined("MPLME_KEY") or define("MPLME_KEY", "hund");
?>